// v432: Leaderboard: your own row uses this device's exact RV and KH counts (no more KH/RV label flipping when an older build wrote the cloud entry).
// v431: Harivangshi and Haridashi treated as separate sampradays for the calendar target colour and the leaderboard streak (each uses only its own count and target).
// v430: Leaderboard shows R, RV and KH separately (exact split, short 'KH' label); Jap screen counters redraw immediately when switching Harivangshi/Haridashi.
// v429: Sampraday fixes — calendar and day popup now count every sampraday (incl. Kaam) and show Radha / RV / KH as separate rows; sampraday-specific target colour, best streak and leaderboard streak; calendar refresh matches the grid.
// v427: Shree Sampraday - Ramanuj branch (Narayan naam jap): stats, N&M, leaderboard, own deity/guru/acharya display.
// v426: N&M lists every trait (RV, RV Audio, KH) in all sampradays; no KH Audio; SitaRaam/Raam in manual add-deduct.
// v425: Vaishnav Vandana (Stotram) now has YouTube audio.
// v423: Ramanandi mode - SitaRaam + Raam chants (stats, N&M, leaderboard) and own Deity/Guru/Acharya jap display.
// v416: Backup/Export JSON now also carries the Drive-allowed flag (with favourites).
// v415: Drive permission is remembered on the server + synced to the account, so every device uploads in one tap (no popups) once allowed anywhere.
// v414: Drive on web: permission once → server keeps it (no more popups). Falls back to 1-hour mode if the server step fails, and shows why.
// v413: Drive token kept across reopens (~1h) and account hint passed, so Google's account screen no longer reappears on every upload.
// v412: Drive backup is one tap again once allowed (no extra 'Continue Upload' card).
// v411: ★ Favourite pads — star on every pad in the ☰ pad list + a ★ tab to see only favourites (synced + in backup).
// v410: Drive button shows ✅ once allowed; first Drive backup asks to allow first; privacy note removed.
// v409: Friendlier Drive permission wording ('Allow Google Drive to Upload Your Backup JSON File') + privacy note.
// v408: Drive backup on iPad/web/Android-Chrome now uploads straight from the browser (no server token step), into folder 'Radha Naam Jap Backups'.
// v407: Drive connect errors now show the real reason from Google/server.
// v406: Settings now has a 'Give Google Drive access' button (for anyone who missed Drive permission at first login).
// v405: Drive connect offered once at first Google login in browsers (Android Chrome/iPad); Android app re-asks Drive consent properly and shows a clear error if Google issues no token.
// v404: Drive JSON backup now works on iPad/web: asks for Google Drive access with a one-tap 'Connect Google Drive' popup (Google Identity Services).
// v403: Google sign-in now always shows the account chooser (web: prompt=select_account; Android: native Google session cleared on sign-out and before sign-in).
// v402: Hit Chaurasi group screen now has Mangala pads / Ras pads buttons that play each type as a group (loop ON/OFF works).
// v401: Wish text can now be edited on the current and queued wishes (was fulfilled only); Gift Your Jap entries can now edit date and stotram name/count, and a stotram can be edited before adding. Cloud sync fixes: no more hanging 'Loading from cloud…' / save-blocked, unsynced jap is kept on reopen. New 'Maharaj Ji' voice for Hit Caturashi Ji and Sri Radha Sudha Nidhi.
// v387: Language popup (Hindi / Bangla / Skip) shows BEFORE the app opens (not after sign-in) whenever this device has no saved language.
// v385: Switching app language (Hindi/Bangla) now also switches the jap types in the Jap dropdown + jap text (unless a jap language was chosen separately).
// v384: Splash/loading screen now follows the saved language (Bangla/Hindi) — ring text + title.
// v383: 28 Names Audio Chant button is now hidden unless Audio Mode is on (like the other audio buttons).
// v382: Yugalashtakam author = Shri Jiva Goswami; word-by-word meaning + translation (Bangla + Hindi) added to Yugalashtakam, Gurvashtakam and Shad-Goswamy-Ashtakam.
// v381: Yugalashtakam now has a second YouTube version (voice button: Original / Version 2).
// v380: New stotram — Jay Nrisimha Shri Nrisimha (Bangla + anuvad) with YouTube audio.
// v379: New stotram — Shri Shri Shad-Goswamy-Ashtakam (Bangla + Hindi) with YouTube audio, in Bangla Gaudiya stotrams.
// v364: New users & guests start with default daily targets (Radha 108 malas, Radha Vallabh 11 malas, 28 Names 36 cycles, Krishnay Vasudevay 12 count, Kaam Vijay 1 mala); 🔥 streak now counts a day when the Radha OR Radha Vallabh target is fulfilled.
// v365: Hit Chaurasi pad picker now has 3 tabs: all pads / Mangala pads / Ras pads.
// v363: Admin Mode - developer can change a viewed user's display name (saved to their account + durable name copy), even if they haven't joined the leaderboard.
// v362: JSON backup keeps the display name - restoring it refreshes Settings and re-saves the cloud copy.
// v361: Display name no longer gets erased after reinstall / re-login - saved in its own cloud doc, restored before any sync, and an empty cloud value can never blank it.
// v360: Gift Your Jap - editing a gift now shows how much more jap is still available (live).
// v359: S&V search also finds Useful Videos+ Links (videos + saved links). v358: S&V — search bar on every page (English / Hindi / Bangla, e.g. "gajendra" finds गजेन्द्र मोक्ष / গজেন্দ্র মোক্ষ). N&M — 3 Lifetime cards under the date (All · Without wish/gift · My selected traits).
// v357: Ghost Mode renamed to Admin Mode; Admin Leaderboard rows open that user's profile (developer-only); Admin list shows Google account name + nickname.
// v354: Add / Deduct Jap Manually — 🎧 audio chips (Radha, Radha Vallabh, Krishnay Vasudevay, Kaam Vijay) always shown; every audio Add / Deduct card (Stats + 28 Names Audio) now has Today, Other Day and Before this app (Lifetime).
// v353: Add / Deduct also adds / deducts the matching audio time (fixed loop length).
// v352: Audio modes (R-A / RV-A / KV-A / KM-A / 28N-A) - Add / Deduct in Statistics; 28 Names audio has its own section in the 28 Names stats.
// v351: Leaderboard - audio chanting always shows as R-A / RV-A / KV-A / KM-A / 28N-A (no more flipping back to plain R); your own row uses this device's live audio counts.
// v350: Audio chant animation (Radha Audio + Radha Vallabh Audio) now always rises from the centre of the display; Stats audio tabs are always visible (no longer need Audio Mode).
// v349: Jap-screen Lifetime box text now wraps inside the box; Stats show each jap type (Radha / RV / KV / Kaam / 28 Names) as ONE card with a Normal / Audio toggle.
// v348: Radha Vallabh / Krishnay Vasudevay / Kaam Vijay audio now have their own History, Audio Chant Log, Stats cards and Leaderboard lines (RV-A, KV-A, Kaam-A).
// v347: Audio Mode now also works for Radha Vallabh Shri Harivansh, Krishnay Vasudevay and Kaam Vijay (audio/radha_vallabh_shri_harivansh.mp3, krishnay_vasudevay.mp3, kaam_vijay.mp3).
// v346: Divine Darshan - added Radha Piyo Ju and Radha Mohan Ju (Radha Keli Kunj, Radha Vallabh Sampraday); new "Seva" line on deity pages.
// v345: 28 Names Audio is counted separately (28-A) in Stats, History and the Leaderboard, like Radha Audio (R-A); Audio Mode chip wording updated.
// v344: 28 Names audio - the name shown follows the clip being played (all modes), faster sync.
// v343: 28 Names Audio Chant (audio/28name_0.mp3) - one clip finished = 1 name counted; precached for offline.
// v342: Audio Mode - Chanting (counted) vs Listening only (not counted); 28 Names + stotram/pad audio locked while the chant plays ("turn off audio chanting first").
// v341: Audio Mode stop limits - type malas OR time, the other (and jap count) is calculated; Save button.
// v340: Audio Mode ON = manual touch on the Radha jap display is disabled (playing or not).
// v339: Daily card - Audio Chant button moved to its own row; tap count + undo moved onto the malas line (no more overlap).
// v338: Audio Chant (audio/radha_naam_chant.mp3) precached for offline.
// v355: Radha Naam Track 1 (audio/radha_naam_track_1.mp3) added as an Audio Mode option.
// ═══════════════════════════════════════════════════════
// RadhaNaam SudhaRasam — Service Worker  v236
// v336: NATIVE BACKGROUND PLAYBACK — Android foreground media service keeps stotram / pad audio playing with the screen off; WebView no longer needs a tap to autoplay.
// v335: BACKGROUND PLAYBACK — verse clips now reuse ONE audio element so auto-next keeps playing with the screen off; auto-next no longer breaks if the page can't redraw; Media Session (lock-screen / notification play, pause, next, previous).
// v334: S&V folder card "Sevak Vani" renamed to "Sevak Vani o Sevak Ji'r anyanya rachana" (Bangla + Hindi).
// v333: AUTOPLAY everywhere — Seva sections with YouTube pads start pad 1 on open; Geet Govindam songs and Gita chapters start their audio when opened; stotrams that resume on a verse with no clip start from the first clip; if the phone blocks autoplay, audio (stotram / deity bhajan / Ved / Padavali) starts on the next tap; Useful Videos mp4 starts muted if sound is blocked.
// v324: S&V — "Priyo Stotra & Padsamuh" folder removed (Haridasi poets → Haridasi folder; Dhruvdas pads → Dhruvdas folder in Radha Vallabh; rest in Radha Vallabh main list); "Favourite Videos" renamed "Useful Videos+ Links" and moved to the bottom, just below Kazi Najrul.
// v323: FIX unstyled / broken-image first load on slow mobile networks. The fetch handler gave up after 2–2.5s and, when nothing was cached yet (first open, or right after a cache bump), returned a plain "Offline" 503 for style.css / app.js / images — so the page showed with no CSS. It now keeps waiting for the network when there is nothing cached to fall back on (cached copy is still used instantly when it exists). Also: Radha Vallabh folder re-organised into sub-folders; Guru Vandana video + translation; Vrindavan Dham Namavali YouTube audio.
// v322: S&V re-organised by sampraday — new folders: Haridasi (Kelimal + Haridasi poets from Priyo Stotra), Priyo Stotra & Padsamuh (own folder, out of Radha Vallabh), Nimbark (all Jayadeva), Vallabh/Rudra (Pushtimarg: Madhurashtakam, Nandakumar Ashtakam), Ramanandi (Hanuman), Ramanuj (coming soon), Shankaracharya (copies for playing); Krishna/Shiv/Gita unchanged.
// v321: Sfut Vani (sfv) gets the ☰ pad list (bottom-left) to jump to any pad — 23 pads then 4 dohas — like Hit Chaurasi / Sevak Vani.
// v320: Bhagavad Gita (700 shlokas) is now pre-loaded in the background once S&V is shown / app is online, so the first tap on Open opens it immediately (before, the first tap only started a download and it opened on the 2nd tap); repeated taps while loading no longer stack.
// v319: Kelimal gets the ☰ pad list (bottom-left) to jump to any pad; Bayalis Leela gets a ☰ verse list inside each leela (scrolls to the chosen verse), like Sevak Vani.
// v318: Hindi Hit Chaurasi text now bundled in stotrams.js (LYRICS_HI.hcj) — Hit_Caturashi_Ji_clean_lyrics.txt no longer needed; Hindi opens instantly.
// v317: Hindi Radha Sudha Nidhi text now bundled in stotrams.js (LYRICS_HI.rsn) — Radha_Sudha_Nidhi_Hindi.txt is no longer needed and Hindi opens instantly.
// v316: Radha Sudha Nidhi (Bengali) opens instantly (no Hindi file download needed any more); Sevak Vani always opens on its section index first, with a faster picker fade-in.
// v315: Radha Sudha Nidhi (Bengali) — shlokas 41–270 were stored as one merged block (all Bengali শব্দার্থ/অর্থ showed on page 41); now one pad per shloka.
// v314: Sevak Vani sections now open pad-by-pad (one card per pad, swipe/arrows, Translation toggle with শব্দার্থ + অর্থ, ☰ pad list) like Radha Sudha Nidhi / Hit Chaurasi, instead of one flat page.
// v310: Added Hey Virat Purush bhajan, full Hindi/Bangla Beyalish Leela (44 leelas), Padyavali, Leela Anukramanika, Rasik Namavali, Vani Prasansa and 25+ more Radha Vallabh texts; Hindi fills for Sevak Bani etc.
// v309: bumped cache to force-invalidate stale stotrams.js — Radha Sudha Nidhi verse text re-checked against the ideal text for all 270 shlokas; শব্দার্থ corrected in shlokas 109, 134, 148, 178, 183, 230, 239.
// v308: Translation of Kelimal + Hit Caturashi Ji is developer-only (note shown to others until dismissed).
// v307: Added Kelimal (Swami Haridas ji, 110 pads — Bangla + Hindi with meaning) under Radha Vallabh Sampraday.
// v306: Radha Sudha Nidhi Bangla অর্থ for shlokas 1–40 re-based on the Hindi व्याख्या (নোট paragraphs kept as-is).
// v305: Radha Sudha Nidhi (Bangla) — word-by-word শব্দার্থ lines added for shlokas 1–10 too.
// v304: Radha Sudha Nidhi (Hindi) — word-by-word शब्दार्थ lines added for shlokas 1–10 (official व्याख्या untouched).
// v303: Added Nandakumar Ashtakam (Bangla + Hindi lyrics, audio/nka_1.mp3) to S&V \u2192 Shree Krishna.
// v300: Added Gopal Ashtakam (Bangla + Hindi lyrics, YouTube audio) to S&V → Shree Krishna.
// v231: Rashikan carousel now opens with the Vrindavan Hari-Traya group photo; Bangla spelling fixed to হরিত্রয়.
// v230: Android app reads Divine Darshan photos live from the site (deities/ no longer bundled in the APK).
// v229: Divine Darshan opens on "All" by default; list preview falls back to the real photo if a thumbnail cannot be saved.
// v228: Navrangi Lal Ji history (found in well by Hit Harivansh), placed under Deoband.
// v227: Hindi "samaj-gayan" changed to "pad gayan".
// v226: Added Radha Navrangi Lal Ji; renamed Laal ju deities; Bengali "pad gaowa" wording.
// v225: Divine Darshan list cards now build their preview image automatically (no need to open the deity first).
// v224: Rasik Jan o Bhakta Jan — 'विस्तार से पढ़ें' detailed biography sheet (61 of 79 saints).
// v223: Divine Darshan of Vrindavan Deities (S&V). Deity photos (deities/<name>/N.jpg|png|webp)
// are served stale-while-revalidate from a persistent cache (radha-jap-deities-v1) that is NOT
// wiped on app updates; audio and list.txt are left to the browser (Range streaming / always fresh).
// v221: bumped cache to force-invalidate stale app.js/style.css — Rasik Jan
// carousel now follows the serial (Hari-Trayi → Rasik Jan → Acharyas → ...)
// with a short note per saint.
// v220: bumped cache to force-invalidate stale style.css — bead ring glow
// filters restored to single lightweight drop-shadows (3 stacked large
// blurs per filled bead made the Jap tap screen laggy as the mala filled).
// v219: bumped cache to force-invalidate stale app.js / style-stotram.css /
// index.html, and precache 79 new portrait photos under ./rashikan/ — adds a
// "Rasik Jan o Bhakta Jan" folder (Stotram section) with an autoplaying photo
// carousel (swipe or arrows to move manually, 3s autoplay), captioned in
// Hindi or Bangla by the Settings language. style-stotram.css cache-busting
// query bumped ?v=128 -> ?v=129.
// v219: bumped cache to force-invalidate stale app.js / style-stotram.css / index.html —
// Ashtayam Seva list now shows a live GPS-based timer under each seva (starts at /
// starts in / time left) and Settings → Daily Reminder gets 8 Ashtayam Seva reminder
// toggles. style-stotram.css cache-busting query bumped ?v=127 -> ?v=128.
// v218: bumped cache to force-invalidate stale app.js / style-stotram.css /
// ashtayam_seva_{hi,bn}.html — Ashtayam Seva pads are now shown verse-by-verse
// (line per line, as on bhajanmarg.com) and every pad has a permanent inline
// audio player below it instead of the YouTube button + bottom bar. index.html's
// style-stotram.css cache-busting query bumped ?v=126 -> ?v=127 alongside this.
// v217: bumped cache to force-invalidate stale app.js — Ashtayam Seva pads play
// in-app as audio (video hidden) via the YouTube embedded player.
// v216: bumped cache to force-invalidate stale app.js/stotrams.js/style-stotram.css —
// adds Ashtayam Seva Paddhati (9 sections, ./ashtayam_seva_{hi,bn}.html)
// as the first item in the Radha Vallabh Sampraday stotram folder.
// v215: bumped cache to force-invalidate stale panchanga.html/js/css —
// fixes two "Others' Rashi Profiles" bugs: (1) the 30s background refresh
// was unconditionally re-rendering #vp-others-card back to the saved-
// profiles LIST even while a user was viewing one profile's detail page,
// making the screen appear to randomly "go back" every 30 seconds;
// vpOthersRenderList() is now skipped (and the open detail re-rendered
// instead) while _vpViewingOtherProfile is set. (2) the premium MSD
// (Mahadasha/Saturn) cards relied entirely on background + box-shadow for
// their visible edge (border: none) — any client still on a cached
// pre-redesign panchanga.css (or any environment where the gradient/glow
// failed to paint) rendered them as flat unstyled text with no visible
// card at all. Added a plain fallback border. index.html's panchanga.css/
// .js cache-busting query bumped from ?v=160 to ?v=161 alongside this —
// that's the change that actually forces every cache layer (browser HTTP
// cache, this SW's cache, any CDN) to treat these as new URLs, since this
// SW's own local-asset cache key strips query strings and a bare CACHE
// bump here doesn't by itself invalidate anything upstream of it. Web/PWA
// clients still running the old cached panchanga.js/html/css now pick up
// the current build on next load.
// v214: bumped cache to force-invalidate stale app.js — v213's bead-ring
// fix (pageshow/visibilitychange) turned out to not be the whole story:
// on iPad the ring's bottom edge can still drift after Safari's
// collapsible toolbar auto-hides a moment after load, growing the
// 100dvh viewport AFTER the ring already measured/drew at the smaller,
// toolbar-still-visible height — a resize that iOS doesn't reliably
// surface as a plain window "resize" event. Added a window.visualViewport
// resize listener plus a blunt ~3.6s post-load re-measure timer (both
// web/iPad only) so the ring converges on the right geometry regardless
// of which exact event does or doesn't fire on a given iPad. Android
// untouched. Web/PWA clients still running old app.js now pick up this
// build on next load.
// v213: bumped cache to force-invalidate stale app.js — the bead-ring
// cold-start revival (added for iPad's "lower border missing" bug) only
// ever ran on the "load" event, which does NOT fire when iOS Safari
// restores the page from its back-forward cache (bfcache) — the actual
// common case of switching away from the app and back, not a true
// relaunch. Added pageshow (event.persisted) and visibilitychange
// listeners so the ring self-corrects on those paths too, not just a
// genuine cold load. Web/PWA clients still running the old app.js now
// pick up this build on next load.
// v208: local JS/CSS/HTML assets (app.js, style.css, panchanga module,
// etc.) now use the SAME network-first strategy the navigate handler has
// used since v154, instead of cache-first/stale-while-revalidate. Root
// cause of "new version doesn't show up until the SECOND app open":
// even once an updated SW has installed and activated in the background,
// the old cache-first strategy for these files would still serve
// whatever was already cached instantly and only refresh it in the
// background for the load AFTER that — so a real code change always
// needed two cold opens to actually appear on screen, not one. Now, with
// a working connection, every local asset is fetched fresh (2.5s
// timeout) on each load and the cache is only a fallback for a slow/
// offline connection — so PWA users see the latest deployed version the
// very next time they open the app, not the time after. Bumped cache to
// force this change to take effect (existing behavior for external CDN
// assets and Firestore/FCM messaging is unchanged).
// v207: bumped cache to force-invalidate stale panchanga.html/js/css —
// tapping a saved profile in the "Others" folder popup no longer closes
// that popup and jumps to the main page's card. Its full breakdown
// (Vaar strip, Rashi card, Dasha/Sade Sati bar, full anga list) now
// renders as a page INSIDE the same #vp-others-overlay folder, with a
// "← Back to Profiles" button that returns to the saved-profiles list
// without leaving the folder. The folder popup itself is now full-screen
// (like the calculator) instead of a small 360px popup, since it needs
// the same room to show that detail. Web/PWA clients still running the
// old cached panchanga.js/html/css now pick up the current build on
// next load.
// v206: bumped cache to force-invalidate stale panchanga.html/js/css —
// fixes the REAL cause of "Save as Their Profile" doing nothing: the
// button's onclick="vpOthersSave(_vpHoroEditingOtherId)" referenced a
// variable that only exists inside panchanga.js's own IIFE closure —
// inline onclick attributes resolve against the global scope, so that
// lookup threw a ReferenceError before vpOthersSave() ever ran, every
// time, for every user. The button now calls vpOthersSave() with no
// argument, and the function reads its own closure variable internally
// instead. This also means the "Others" folder popup — already built
// in v201/v203 — can finally hold anything, since nothing could ever
// actually get saved into it before now. Web/PWA clients still running
// the old cached panchanga.js/html now pick up the current build on
// next load.
// v205: bumped cache to force-invalidate stale panchanga.html/js/css —
// "Calculate Rashi" inside the Add/Edit Profile popup (Your Rashi or
// Others) now shows the FULL breakdown right there — Vaar strip, Birth
// Moon Rashi card (with lord/deity), Mahadasha & Sade Sati bar, and the
// complete Tithi/Nakshatra/Yoga/Karana anga list — instead of just the
// Rashi name. Fixes report that calculating an Other profile's rashi
// showed only the Moon sign with no other detail. Web/PWA clients still
// running the old cached panchanga.js — where the inline result was
// Rashi-name-only — now pick up the current build on next load.
// v204: bumped cache to force-invalidate stale panchanga.html/js/css —
// "Calculate Rashi" inside the Add/Edit Profile popup (Your Rashi or
// Others) no longer closes that popup and jumps to the main page's
// result section. It now shows a compact inline result right there,
// directly above the existing Save button, so calculating and saving
// happen in one place instead of the flow appearing to "leave" the
// popup. The old full-page result view is kept only for a bare
// calculator with no save option, which no current button reaches.
// v203: bumped cache to force-invalidate stale panchanga.html/js/css —
// the header "Others" button now opens a dedicated list popup
// (#vp-others-overlay) showing saved other-person profiles directly,
// instead of scrolling down to a section buried below the whole
// "Your Rashi" breakdown. Adding a profile opens the existing
// calculator on top of this popup as before; tapping a saved profile
// closes the popup and shows that profile's full breakdown further
// down the page, unchanged. Web/PWA clients still running the old
// cached panchanga.js — where "Others" scrolled into the buried
// section instead — now pick up the current build on next load.
// v202: bumped cache to force-invalidate stale app.js — ships the real
// delta-sync rework: fbPushDelta() now actually sends only changed
// fields (arrayUnion for grow-only logs like malaLog/activityLog)
// instead of silently aliasing to a full-state push; skips the write
// entirely when nothing changed since the last confirmed sync; adds a
// "Tap to retry" button that appears if the sync pill sits on
// "Syncing…" for 60s straight; adds a rolling sync debug log
// (localStorage: rjap_sync_debug_log) for diagnosing future stuck-sync
// reports. fbPushFull() (restore/initial-push/full-overwrite paths) is
// unchanged. Web/PWA clients still running the old always-full-push
// app.js — the original cause of the "stuck syncing forever" report —
// now pick up the current build on next load.
// v201: bumped cache to force-invalidate stale vedic-panchanga module
// files (panchanga.html/css/js) — ships the "Others" Janmo Tithi & Rashi
// fixes: the header Others button now goes to a saved-profiles list
// instead of opening the calculator directly, each mode (Your Rashi vs
// Others) only shows its own Save CTA, and the button is now
// error-hardened end-to-end (vpOthersButtonClick → vpOthersGoToList →
// vpHoroOpenOther, each catching failures from the one before) so it can
// never silently do nothing even if a Firestore/auth check throws. Web/
// PWA clients that were still running a cached pre-fix panchanga.js —
// which is exactly why the button could appear "unresponsive" even after
// the source files were updated — now pick up the current build on next
// load.
// v197: bumped cache to force-invalidate stale app.js/index.html — ships
// the leaderboard/Ghost Mode fixes (unconditional presence + leaderboard
// doc creation on login, hardened login chain, users/*/data collection-
// group scan in Ghost Mode search, one-click leaderboard backfill). Web/
// PWA clients that were still running a cached pre-fix app.js — and could
// therefore still be hitting old opt-out-deletes-the-doc behavior — now
// pick up the current build on next load.
// v196: bumped cache to force-invalidate stale app.js/index.html — Update
// App now shows an "Open permission settings →" link that jumps straight
// to Android's install-permission screen for this app (via a new method
// on the existing custom PowerPermissions native plugin), instead of just
// describing where to find it in text. Shown after any install attempt
// (success or failure) since MIUI/Xiaomi can silently swallow this
// specific failure — tapping it is a harmless no-op if the install
// actually did work. Requires the native side patch
// (patch_power_permissions.py) applied to android-src/PowerPermissionsPlugin.java.
// v195: bumped cache to force-invalidate stale app.js — extends the v194
// mala start-time fix to survive fully closing and reopening the app, not
// just switching modes within one session. Each jap type's in-progress
// mala timing now persists to its own localStorage key
// (rjap_malaStash_<mode>), checked both when switching modes and on app
// boot (using whichever mode was active when the app was last closed) —
// closes the one edge case v194's changelog flagged as still open.
// v194: bumped cache to force-invalidate stale app.js — fixes History
// showing a falsely-short duration for a mala interrupted by switching
// jap types mid-way (e.g. 93/108 Radha taps, switch to RV, complete an
// RV mala, switch back and finish Radha's last 15). Root cause:
// malaWallStart/_currentMalaStartTs were shared globals instead of
// per-mode, so the other mode's own first-tap reset (or its mala-
// completion reset) wiped the original mode's in-progress start
// timestamp. switchJapMode() now stashes the outgoing mode's timing
// state and restores the incoming mode's, so each jap type keeps its
// own undisturbed mala clock across switches. NOTE: this fix is
// session-only — switching modes, then fully closing and reopening the
// app before switching back, can still lose the stash (only the most-
// recently-active mode's timing persists to localStorage across a
// restart). Worth revisiting if that edge case comes up in practice.
// v193: bumped cache to force-invalidate stale app.js — Update App now
// gives clear guidance (Settings → Apps → RadhaNaam SudhaRasam → "Install
// unknown apps" / MIUI's "Other permissions") when the download succeeds
// but the installer can't be launched — this is almost always a missing
// Android permission, not a bug, and some manufacturers (MIUI/Xiaomi)
// silently block the launch instead of showing any error at all. Also:
// tapping Update again after fixing the permission now reuses the
// already-downloaded APK (tagged by target version) instead of
// re-downloading the full ~137MB every time.
// v192: bumped cache to force-invalidate stale app.js — fixes the Update
// App check showing "No release published yet on GitHub" when it's
// actually a GitHub API rate-limit hit (60 unauthenticated requests/hour,
// shared per network — easy to exhaust during heavy testing). Now caches
// the last known result for 30 min so it doesn't re-hit the API on every
// app open, and falls back to that cached result on a rate-limit/network
// failure instead of showing a misleading "no release" message.
// v191: bumped cache to force-invalidate stale app.js — adds a foreground
// catch-up check for the daily Drive backup, run once on every app open.
// If the chosen backup time already passed today and it hasn't run yet
// (checked via the same bgsync_last_drive_backup_date marker runner.js
// uses), it fires immediately using the live app's own connection —
// covers the case where background/runner.js's periodic wake (Android
// platform minimum ~15min, no exact-alarm option) missed the window
// entirely because the phone was closed/offline at the time.
// v190: bumped cache to force-invalidate stale app.js — fixes Update App
// download failing with a bare "Error downloading file: <url>" message.
// Root cause: a known Capacitor Filesystem bug (ionic-team/capacitor
// #6896, #7108, #1835) where downloadFile() throws ENOENT if its target
// directory (here, the app's own Cache dir) hasn't been created yet by
// Android — common on a fresh install/update before anything else has
// written to Cache. Added recursive:true so it creates the folder
// instead of failing. Also logs the full underlying error object to
// console for easier diagnosis if a future failure has a different cause.
// v189: bumped cache to force-invalidate stale app.js/index.html —
// Update App card now always shows "Installed version: vX.X.X" as a
// persistent line, independent of whether the GitHub update check
// succeeds — works offline or with zero releases published. Also adds a
// friendly "No release published yet on GitHub" message instead of
// silently doing nothing when GitHub returns 404 (e.g. after deleting
// all releases). NOTE: the GitHub *tag* must stay numeric (v1.0.6 etc)
// for the version comparison to keep working — the release *title* can
// be anything (e.g. "MashuTheKingCat 1").
// v188: bumped cache to force-invalidate stale app.js/index.html —
// Settings > Google Drive Backup now has a time picker (device-local)
// under the Daily Auto-Backup toggle. Chosen hour/minute is staged into
// CapacitorKV so background/runner.js (patched separately via
// patch_runner.py — not part of this www bundle) can check "am I within
// ~35 min of the chosen time, and haven't already backed up today?"
// before uploading, instead of just firing on whatever cycle WorkManager
// happens to wake it.
// v187: bumped cache to force-invalidate stale app.js — drops
// @capacitor/file-transfer entirely (its native Android module needs a
// newer Gradle/AGP toolchain than this project has and reliably fails
// to build, even after a full Gradle cache wipe — "Failed to create Jar
// file ... bcprov-jdk18on-1.79.jar"). The Update App download now uses
// @capacitor/filesystem's own downloadFile() instead — already bundled
// in this project, not deprecated until Filesystem v7.1.0 (this project
// is on Capacitor 6), and just as native/CORS-free/disk-direct.
// v186: bumped cache to force-invalidate stale app.js/style.css/index.html —
// the Update App card now turns blue and pulses with a soft glow whenever
// a newer version is actually available (via .update-available class),
// instead of just a thin gold border. Stays in its normal quiet state
// when already up to date or before the check has run.
// v185: bumped cache to force-invalidate stale app.js — fixes "Update
// failed: Failed to fetch" when tapping Update App. Root cause: the app's
// WebView origin isn't CORS-allowed by GitHub's release/API hosts, so
// plain fetch() was blocked before the request left the device. Now uses
// CapacitorHttp.request() for the small version-check JSON call, and the
// dedicated @capacitor/file-transfer plugin for the actual ~137MB APK
// download — both run at the native layer (no CORS), and file-transfer
// writes straight to disk instead of pulling the whole APK through the
// JS bridge as base64 (which risked an OOM crash at that file size).
// Requires: npm install @capacitor-community/file-opener@6 @capacitor/file-transfer
// v184: bumped cache to force-invalidate stale app.js —
// adds automatic "Update available — vX.X.X" detection on app launch:
// compares the installed app's version (Capacitor App.getInfo()) against
// the latest GitHub Release's tag via the GitHub API, and updates the
// Settings card's status line accordingly. Tapping the button still just
// downloads+installs the latest release either way — this only adds the
// "is there something new" indicator, and fails silently (no crash, no
// user-facing error) if offline or run outside the installed app.
// v183: bumped cache to force-invalidate stale app.js/index.html —
// adds an in-app "Update App" card at the top of Settings that downloads
// the latest APK from a GitHub Release via Capacitor Filesystem and hands
// it to the system installer (@capacitor-community/file-opener — see
// setup notes above checkAppUpdate() in app.js). Also fixes autoLoadHistory
// permanently disabling itself after one failed timing race, which could
// leave the History section's From/To fields stuck blank for the rest of
// the session ("Please select both From and To dates" even though a
// preset button looked selected).
// v182: bumped cache to force-invalidate stale style.css — fixes the
// Hit Chaurasi Ji player's prev/next arrows being pushed off-screen
// (and clipped by body{overflow-x:hidden}) on narrow Android phones,
// while showing fine on wider screens like iPad. .hcj-player row is
// now compacted under 480px width, plus a hidden-scrollbar fallback.
// v181: bumped cache to force-invalidate stale app.js/index.html/style.css —
// picks up: dedicated KV-only History section (table column, Period Totals
// card, drill-down) mirroring the existing HK-only history view.
// v180: bumped cache to force-invalidate stale app.js/index.html/style.css —
// picks up: KV mode's persistent tap display (#kvPersist), matching HK's
// stays-until-next-tap behavior instead of only a fading floating text.
// v179: bumped cache to force-invalidate stale app.js/index.html/style.css —
// picks up: 15s idle-pause grace for HK/KV modes, and the white-page
// email-style notification inbox redesign.
// v178: bumped cache to force-invalidate stale app.js/index.html/style.css —
// picks up: notification history inbox + unread badges, the hcj-next-btn/
// hcj-prev-btn visibility fix, and the notification bell in Settings.
// v177: bumped cache to force-invalidate stale app.js/index.html — adds
//  the PERMANENT Gift Ledger: every gift is now also written to its own
//  IndexedDB record + its own Firestore document immediately (no debounce),
//  isolated from the state blob that gets reset on UID change/cold start,
//  so a gift entry can no longer be silently dropped by the sync race.
// v176: bumped cache to force-invalidate stale app.js — picks up:
//  (1) Milestones total-jap fix — nets each jap type (Radha/RV/HK/KV)
//      against its own gift/deduct counter instead of pooling all
//      histories then subtracting only one counter.
//  (2) New Milestones "Consideration" chips (msConsider) — choose which
//      jap types count toward Bhagvat Prapti milestones, any combination.
//  (3) 28 Names milestone rule — contributes 0 while ANY wish (sankalp)
//      is active, since wishes chain continuously; only counts when no
//      wish is active.
//  (4) Community leaderboard breakdown fix — per-type totals now netted
//      against gifts (matching totalJap), plus a "🎁 X gifted" note per
//      type so a small netted count next to a long raw chanting time
//      reads as "gifted most of it" instead of a mismatch.
// v175: bumped cache to force-invalidate stale app.js/index.html — adds
// full Add/Deduct Jap Manually (Today / Other Day / Before This App /
// Name Jap — Lifetime) to the 28 Names Statistics screen, matching the
// main jap section's manual-entry feature.
// v174: bumped cache to force-invalidate stale app.js/index.html/style.css —
// adds the new "Krishnay Vasudevay Haraye Paramatmane" (KV) jap type
// alongside Radha / Radha Vallabh / Hare Krishna, with its own history,
// targets, stats, leaderboard and Firebase sync.
// v173: bumped cache to force-invalidate stale app.js — picks up the
// Firebase sync-hang fix, Brahma Muhurta reminder timing fix, and the
// native Share sheet fix (APK was silently falling back to copy-link
// because navigator.share doesn't exist in Capacitor's WebView).
// v172: bumped cache to force-invalidate stale app.js/index.html/style.css
// after adding Gaudiya/ISKCON top-deity + Acharya/Gurudev jap-display photos
// and fixing the app-boot sequence to call applyBgPhotos() on load.
// v171: re-added FCM background push handling (web/PWA) via
// firebase-messaging-compat, using the same firebaseConfig as app.js.
// Native (APK) push does NOT go through this file — that's handled by
// @capacitor-firebase/messaging directly.
// v169: manifest.json updated — added display_override, real screenshots
// (replaces placeholder icon-512.png screenshot entries)
//
// v156 fixes (vs v154):
//  • Promoted ./vedic-panchanga/panchanga.html, .css, .js to CORE_ASSETS so
//    install BLOCKS on them. Fixes "Vedic Panchanga module failed to load"
//    on first open / after update where the HTML fragment fetch failed
//    before the lazy cache step had completed.
//  • Bumped cache name to invalidate any stale v154 entry that may have
//    cached a failed/empty panchanga.html response.
// ═══════════════════════════════════════════════════════
// v271: bumped cache to force-invalidate stale app.js / index.html — removed the Permanent Gift Record card and its ledger code.
// v264: added Govinda Damodara Stotram (Laghu) under Shree Krishna (flat view + audio gdm_1.mp3).
// v272: bumped cache to force-invalidate stale app.js — live stotrams can use ONE audio.mp3 with per-verse start times (meta.json "marks"); the blue highlight follows the audio.
// v273: bumped cache to force-invalidate stale app.js — timed live stotrams can also play audio-only from a YouTube link (meta.json "youtube").
// v274: bumped cache to force-invalidate stale app.js — fixes YouTube-audio live stotrams not starting (play was gated on an mp3 path).
// v285: bumped cache to force-invalidate stale app.js / stotrams.js — Hit Sfut Vani plays verse-by-verse from one recording (audio/sfv_1.mp3); Priya Ju & Laal Ju Namavali lyrics replaced, flat page with YouTube (default) + offline Maharaj Ji audio (audio/nmb_1.mp3).
// v286: bumped cache to force-invalidate stale app.js / stotrams.js — Radha Vallabh folder re-ordered (Hit Chaurasi, Radha Sudha Nidhi, Sevak Vani with compulsory daily-12-pad badges, Sfut Vani, Yamunashtak, Mangal Gan, Namavali, Bayalis Leela, then Favourite Stotra, Pads); no pāṭh counter there; 'Ju Maharaj' after Hariram Vyas; Bilvamangal Thakur / Mahadev author credits + portraits.
// v292: Hit Chaurasi pad 35 Shuvam plays only via the YouTube link (online only); hcj_shuvam_35.mp3 no longer used.
// v291: Removed Jhoolat Dou Naval Hindolein's own song link; that YouTube clip is now Hit Chaurasi pad 35, Shuvam version.
// v290: Automatic daily pad tracking for Hit Chaurasi (12), Radha Sudha Nidhi (5), Sevak Vani (5): not read / N more to go / ✅.
// v289: Rashikan carousel: added Shri Bilvamangal Thakur (Lilashuk) portrait p085.jpg with Hindi/Bangla biography.
// v288: Stotram folders: counters removed everywhere; Favourite Stotra, Pads shown open in the list; daily ✅ 'read today' tick on compulsory stotrams.
// v287: bumped cache to force-invalidate stale stotrams.js — compulsory badge for Radha Sudha Nidhi & Sevak Vani is now 5 pads daily (with meaning).
// v293: bumped cache to force-invalidate stale app.js / stotrams.js / index.html — pad tracing for Hit Chaurasi, Radha Sudha Nidhi and Sevak Vani (resume on last-read pad, reading time synced to Firebase + leaderboard, included in Export All Data); 'Favourite Stotra, Pads' renamed to Priyo Stotram & Pad Samuh (Hindi/Bangla).
// v294: added Rasik Namavali (Radha Vallabh Sampraday, above Bayalis Leela) with Bengali + Hindi lyrics and YouTube audio
// v295: Rasik Namavali audio link changed
// v296: added Bhakta Namavali (Rasik Dev Ju) below Rasik Namavali; tappable red names with notes
// v297: added Bhaje Vrajaikamandanam (Krishnashtakam) to the Krishna section
// v298: added Kamalapati Ashtakam to the Krishna section
// v299: added Damodarashtakam (word-by-word) to Brahma Madhva Gaudiya Sampraday
// v301: added Ahe Nila Shaila (Bhakta Salabega, Odia; Bangla + Hindi lyrics with meaning, YouTube audio) at the top of S&V → Shree Krishna.
// v417: bumped cache to force-invalidate stale app.js — Drive permission is remembered in Firebase (driveGranted) so new browsers/devices don't ask again.
// v418: bumped cache to force-invalidate stale app.js / index.html — Play-Store build: APK download/updater removed, Delete My Account added.
// v420 (Play build + dev email): bumped cache to force-invalidate stale app.js — Play build cleanup (install-permission helper disabled).
// v421: audio/ folder no longer bundled in the Android app; installed app streams it from the website.
// v422: bumped cache to force-invalidate stale app.js / style.css / index.html — Haridashi Sampraday (Radha + Kunj Vihari / Sri Haridas, own Deity/Guru/Acharya photos, own lifetime target); Nimbark Deity/Guru/Acharya jap-display photos + Yugal mantra animation now matches Hare Krishna; reopened wishes no longer stay paused.
const CACHE = 'radha-jap-v439';
// Deity photos live in their own cache so they survive every app update (viewed once = offline forever).
const DEITY_CACHE = 'radha-jap-deities-v1';

// ── FCM background push (web/PWA only — no effect inside the Capacitor
// APK, which never registers this SW for messaging). Wrapped in try/catch
// because importScripts throws on browsers with no network at SW-install
// time; background push just won't be available there, nothing else breaks. ──
try {
  importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js');
  importScripts('https://www.gstatic.com/firebasejs/9.23.0/firebase-messaging-compat.js');
  firebase.initializeApp({
    apiKey: "AIzaSyCvvXEdsJjXpTbITE2HuyYFnPZfZIkxVWA",
    authDomain: "guru-kripahi-kevalam-108.firebaseapp.com",
    projectId: "guru-kripahi-kevalam-108",
    storageBucket: "guru-kripahi-kevalam-108.firebasestorage.app",
    messagingSenderId: "368485403238",
    appId: "1:368485403238:web:a3ab5c1427ad0c40fffba7",
  });
  const messaging = firebase.messaging();
  messaging.onBackgroundMessage((payload) => {
    const n = payload.notification || {};
    self.registration.showNotification(n.title || "RadhaNaam SudhaRasam", {
      body: n.body || "",
      icon: './icon-192.png',
      badge: './icon-192.png',
    });
  });
} catch (e) {
  console.warn('FCM background messaging not available in this SW context:', e);
}

// Core assets — install BLOCKS on these. Anything the first paint needs
// must live here, otherwise users see a network round-trip on first open.
const CORE_ASSETS = [
  './',
  './index.html',
  './404.html',
  './style.css',
  './app.js',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  // Promoted in v154 — these are visible on first paint:
  './guru.jpg',
  './radha-coin.png',
  './bhagavadik-bank.png',
  './gurudev/1.png',
  './radha_vallabh/1.png',
  './hitju_maharaj/1.png',
  // Promoted in v155 — Vedic Panchanga module (was failing to load on first
  // open because the fragment fetch raced ahead of the lazy cache step).
  './vedic-panchanga/panchanga.html',
  './vedic-panchanga/panchanga.css',
  './vedic-panchanga/panchanga.js',
];

// Large / optional local assets — cached in background, not blocking install
const LAZY_LOCAL_ASSETS = [
  './style-stotram.css',
  './stotrams.js',
  './panchangData.js',
  './gurudev/2.png',
  './Panchojanno%20Shankya.mp3',
  './audio/radha_naam_chant.mp3',
  './audio/radha_naam_track_1.mp3',
  './audio/radha_naam_track_3.mp3',
  './audio/28name_0.mp3',
  './audio/radha_vallabh_shri_harivansh.mp3',
  './audio/krishnay_vasudevay.mp3',
  './audio/kaam_vijay.mp3',
  // Rasik Jan o Bhakta Jan carousel (79 portraits) — added v219.
  './rashikan/p000.jpg',
  './rashikan/p001.jpg',
  './rashikan/p002.jpg',
  './rashikan/p003.jpg',
  './rashikan/p004.jpg',
  './rashikan/p005.jpg',
  './rashikan/p006.jpg',
  './rashikan/p007.jpg',
  './rashikan/p008.jpg',
  './rashikan/p009.jpg',
  './rashikan/p010.jpg',
  './rashikan/p011.jpg',
  './rashikan/p012.jpg',
  './rashikan/p013.jpg',
  './rashikan/p014.jpg',
  './rashikan/p015.jpg',
  './rashikan/p016.jpg',
  './rashikan/p017.jpg',
  './rashikan/p018.jpg',
  './rashikan/p019.jpg',
  './rashikan/p020.jpg',
  './rashikan/p021.jpg',
  './rashikan/p022.jpg',
  './rashikan/p023.jpg',
  './rashikan/p024.jpg',
  './rashikan/p025.jpg',
  './rashikan/p026.jpg',
  './rashikan/p027.jpg',
  './rashikan/p028.jpg',
  './rashikan/p029.jpg',
  './rashikan/p030.jpg',
  './rashikan/p031.jpg',
  './rashikan/p032.jpg',
  './rashikan/p033.jpg',
  './rashikan/p034.jpg',
  './rashikan/p035.jpg',
  './rashikan/p036.jpg',
  './rashikan/p037.jpg',
  './rashikan/p038.jpg',
  './rashikan/p039.jpg',
  './rashikan/p040.jpg',
  './rashikan/p041.jpg',
  './rashikan/p042.jpg',
  './rashikan/p043.jpg',
  './rashikan/p044.jpg',
  './rashikan/p045.jpg',
  './rashikan/p046.jpg',
  './rashikan/p047.jpg',
  './rashikan/p048.jpg',
  './rashikan/p049.jpg',
  './rashikan/p050.jpg',
  './rashikan/p051.jpg',
  './rashikan/p052.jpg',
  './rashikan/p053.jpg',
  './rashikan/p054.jpg',
  './rashikan/p055.jpg',
  './rashikan/p056.jpg',
  './rashikan/p057.jpg',
  './rashikan/p058.jpg',
  './rashikan/p059.jpg',
  './rashikan/p060.jpg',
  './rashikan/p061.jpg',
  './rashikan/p062.jpg',
  './rashikan/p063.jpg',
  './rashikan/p064.jpg',
  './rashikan/p065.jpg',
  './rashikan/p066.jpg',
  './rashikan/p067.jpg',
  './rashikan/p068.jpg',
  './rashikan/p069.jpg',
  './rashikan/p070.jpg',
  './rashikan/p071.jpg',
  './rashikan/p072.jpg',
  './rashikan/p073.jpg',
  './rashikan/p074.jpg',
  './rashikan/p075.jpg',
  './rashikan/p076.jpg',
  './rashikan/p077.jpg',
  './rashikan/p078.jpg',
  './rashikan/p080.JPG',
  './rashikan/p081.jpg',
  './rashikan/p082.jpg',
  './rashikan/p083.jpg',
  './rashikan/p084.jpg',
  './rashikan/p085.jpg',
  './rashikan/p086.jpg',
];

const EXTERNAL_ASSETS = [
  'https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js',
  'https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js',
  'https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore-compat.js',
  'https://fonts.googleapis.com/css2?family=Tiro+Devanagari+Hindi&family=Hind+Siliguri:wght@400;600;700&family=Cinzel+Decorative:wght@400;700&family=EB+Garamond:wght@400;600&family=Inter:wght@300;400;500;600&family=Noto+Sans+Devanagari:wght@400;700&family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap',
  'https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js',
];

const BYPASS = [
  'firestore.googleapis.com',
  'identitytoolkit.googleapis.com',
  'securetoken.googleapis.com',
  'firebaseinstallations.googleapis.com',
  'firebase.googleapis.com',
  'firebaseio.com',
  'oauth2.googleapis.com',
  'accounts.google.com',
];

const BYPASS_PREFIXES = [
  'https://api.prokerala.com',
  'https://astronomy-engine',
];

function withinScopePath(pathname) {
  const scopePath = new URL(self.registration.scope).pathname;
  return pathname.startsWith(scopePath) ? pathname.slice(scopePath.length) : null;
}

function toLocalCacheKey(requestOrUrl) {
  const raw = typeof requestOrUrl === 'string' ? requestOrUrl : requestOrUrl.url;
  const url = new URL(raw, self.location.origin);
  if (url.origin !== self.location.origin) return null;
  let relativePath = withinScopePath(url.pathname);
  if (relativePath == null) return null;
  if (!relativePath || relativePath === '/') return './index.html';
  if (relativePath.startsWith('/')) relativePath = relativePath.slice(1);
  return `./${relativePath}`;
}

function fetchWithTimeout(request, options, ms) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), ms);
  return fetch(request, { ...options, signal: controller.signal })
    .finally(() => clearTimeout(tid));
}

async function cacheLocalAsset(cache, asset) {
  try {
    const response = await fetchWithTimeout(asset, { cache: 'reload' }, 8000);
    if (response && response.ok) await cache.put(asset, response.clone());
  } catch (_) {}
}

async function cacheExternalAsset(cache, url) {
  try {
    const response = await fetchWithTimeout(url, { cache: 'reload', mode: 'no-cors' }, 8000);
    if (response && (response.ok || response.type === 'opaque')) await cache.put(url, response.clone());
  } catch (_) {}
}

async function storeResponse(cacheKey, response) {
  if (!response || (!response.ok && response.type !== 'opaque')) return;
  try {
    const cache = await caches.open(CACHE);
    await cache.put(cacheKey, response.clone());
  } catch (_) {}
}

// Network-first with a soft timeout. After `ms` we serve the cached copy if there is one (and let the
// request keep running in the background to refresh the cache). If there is NOTHING cached yet we keep
// waiting for the network instead of failing — an aborted request here is what used to leave the page
// without CSS/JS on slow connections.
async function networkFirstSoft(event, request, cacheKey, ms) {
  const netPromise = fetch(request, { cache: 'no-cache' }).then((res) => {
    if (res && res.ok) storeResponse(cacheKey, res.clone()).catch(() => {});
    return res;
  });
  netPromise.catch(() => {});                 // never an unhandled rejection
  try { event.waitUntil(netPromise.catch(() => {})); } catch (_) {}
  const TIMEOUT = Symbol('timeout');
  try {
    const first = await Promise.race([netPromise, new Promise((r) => setTimeout(() => r(TIMEOUT), ms))]);
    if (first !== TIMEOUT) {
      if (first && first.ok) return first;
      const cached = await caches.match(cacheKey);
      return cached || first;
    }
    const cached = await caches.match(cacheKey);
    if (cached) return cached;                // slow network + have a copy → instant
    return await netPromise;                  // slow network + nothing cached → wait, don't fail
  } catch (_) {
    const cached = await caches.match(cacheKey);
    return cached || new Response('Offline', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
  }
}

// ── INSTALL: block on CORE (incl. above-the-fold images); lazy + external in background ──
self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await Promise.allSettled(CORE_ASSETS.map((asset) => cacheLocalAsset(cache, asset)));
    Promise.allSettled(LAZY_LOCAL_ASSETS.map((asset) => cacheLocalAsset(cache, asset)));
    Promise.allSettled(EXTERNAL_ASSETS.map((asset) => cacheExternalAsset(cache, asset)));
  })());
});

// ── ACTIVATE: delete old caches, then claim open clients and self-heal an
// empty/partial cache (see below). ──
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    const oldKeys = keys.filter((key) => key !== CACHE && key !== DEITY_CACHE);
    await Promise.all(oldKeys.map((key) => caches.delete(key)));

    // v212 offline fix: claim currently-open clients immediately instead of
    // waiting for the next navigation. The old comment here said this was
    // removed to avoid a mid-session "takeover flicker" — but that flicker
    // was actually caused by app.js's old location.reload() on
    // controllerchange (removed back in v154), not by claim() itself.
    // Claiming now means: if this is the very FIRST activation (fresh
    // install, no prior SW), the current session is covered by an active
    // SW right away instead of only from the next cold app-open onward —
    // closing the exact gap where "open once online, immediately go
    // offline and relaunch" could still hit the browser's native offline
    // page instead of this SW's own cached shell.
    await self.clients.claim();

    // Self-heal: if CORE_ASSETS somehow failed to cache during install
    // (e.g. install ran on a flaky connection — cacheLocalAsset() swallows
    // its own errors so install() always "succeeds" even with an empty
    // cache), retry them now. Cheap no-op if everything's already cached.
    try {
      const cache = await caches.open(CACHE);
      const missing = [];
      for (const asset of CORE_ASSETS) {
        if (!(await cache.match(asset))) missing.push(asset);
      }
      if (missing.length) {
        console.warn('[SW] self-heal: re-caching', missing.length, 'missing core asset(s)');
        await Promise.allSettled(missing.map((asset) => cacheLocalAsset(cache, asset)));
      }
    } catch (_) {}

    const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    clients.forEach((client) => client.postMessage({ type: 'SW_UPDATED', version: CACHE }));
  })());
});

// ── FETCH ──
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);

  if (BYPASS.some((host) => url.href.includes(host))) return;
  if (BYPASS_PREFIXES.some((prefix) => url.href.startsWith(prefix))) return;
  if (url.pathname.indexOf('/stotram-live/') >= 0) return;

  // ── Navigation requests (page load) ──
  // v154: NETWORK-FIRST with 2s timeout. Fixes "old HTML + new app.js" mismatch.
  // - If network responds within 2s, use it and update cache.
  // - If network is slow/offline, serve cached index.html.
  if (event.request.mode === 'navigate') {
    event.respondWith(networkFirstSoft(event, event.request, './index.html', 2000));
    return;
  }

  // -- Divine Darshan deity photos read live from the deployed site (Android app) --
  // Keeps viewed photos for offline use. Falls back to a plain network load if the CORS fetch fails.
  if (url.origin === 'https://radharadharadha.vercel.app' && url.origin !== self.location.origin &&
      url.pathname.indexOf('/deities/') >= 0 && !url.search && /\.(jpe?g|png|webp|gif|avif)$/i.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(DEITY_CACHE);
      const cached = await cache.match(url.href);
      const net = fetch(url.href, { mode: 'cors' }).then((res) => {
        if (res && res.ok && res.status === 200) cache.put(url.href, res.clone()).catch(() => {});
        return res;
      }).catch(() => null);
      if (cached) { event.waitUntil(net); return cached; }
      const res = await net;
      if (res) return res;
      try { return await fetch(event.request); } catch (_e) {}
      return new Response('Offline', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
    })());
    return;
  }

  // -- Divine Darshan deity files --
  // Photos: stale-while-revalidate into DEITY_CACHE (big files, so no 2.5s network timeout).
  // Anything else under /deities/ (audio.mp3, list.txt) goes straight to the network/browser.
  if (url.origin === self.location.origin && url.pathname.indexOf('/deities/') >= 0) {
    if (!/\.(jpe?g|png|webp|gif|avif)$/i.test(url.pathname)) return;
    event.respondWith((async () => {
      const cache = await caches.open(DEITY_CACHE);
      const cached = await cache.match(event.request);
      const net = fetch(event.request).then((res) => {
        if (res && res.ok && res.status === 200) cache.put(event.request, res.clone()).catch(() => {});
        return res;
      }).catch(() => null);
      if (cached) { event.waitUntil(net); return cached; }
      const res = await net;
      return res || new Response('Offline', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
    })());
    return;
  }

  const localCacheKey = toLocalCacheKey(event.request);
  if (localCacheKey) {
    // Local assets: NETWORK-FIRST with a 2.5s timeout — same pattern as
    // navigation above. On a normal open with a working connection this
    // always fetches the current deployed file, so a code change shows up
    // the very next time the app is opened. Falls back to whatever's
    // cached only if the network is slow/unavailable, so offline use is
    // unaffected.
    event.respondWith(networkFirstSoft(event, event.request, localCacheKey, 2500));
    return;
  }

  // External assets (fonts, CDN): cache-first, fallback to network
  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    try {
      const response = await fetchWithTimeout(event.request, {}, 8000);
      await storeResponse(event.request, response);
      return response;
    } catch (_) {
      return new Response('Offline', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8' } });
    }
  })());
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});
