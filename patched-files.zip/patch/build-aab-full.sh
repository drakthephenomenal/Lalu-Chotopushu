#!/bin/bash
# ============================================================================
# build-aab-full.sh  -  FULL offline build as a GOOGLE PLAY AAB
#
# Same as build-apk-full.sh except deities: only the FIRST photo of each deity is bundled,
# the other deity photos (and each deity's audio.mp3) load from the website.
# All audio, videos and stotram-live work offline; the media rides in Play Asset Delivery packs (add-media-packs.sh),
# so the base module stays small and Play accepts the bundle.
#
# Usage (repo root):  bash build-aab-full.sh
# ============================================================================
set -e
[ -f setup-www.sh ] && [ -f build-android.sh ] && [ -f add-media-packs.sh ] || { echo "❌ Run from repo root (setup-www.sh, build-android.sh, add-media-packs.sh needed)."; exit 1; }
for d in audio videos deities; do   # deities/ is needed to pick each first photo
  [ -d "$d" ] || { echo "❌ Folder '$d/' is missing from the repo - nothing to pack."; exit 1; }
done

B1="setup-www.sh.bak-$$"; B2="build-android.sh.bak-$$"
cp setup-www.sh "$B1"; cp build-android.sh "$B2"
restore() {
  mv "$B1" setup-www.sh; mv "$B2" build-android.sh
  echo "↩ Restored original setup-www.sh and build-android.sh"
  rm -rf www && bash setup-www.sh >/dev/null 2>&1 || true
}
trap restore EXIT

# 1. app.js (www copy only): use the packed audio/videos instead of the website / GitHub
cat >> setup-www.sh <<'EOS'

python3 - <<'PYEOF'
import re, sys
p = 'www/app.js'
s = open(p, encoding='utf-8').read()
def rep(old, new, label, regex=False):
    global s
    if regex: s2, n = re.subn(old, new, s)
    else: n = s.count(old); s2 = s.replace(old, new)
    if n < 1: sys.exit("PATTERN NOT FOUND (app.js changed?): " + label)
    s = s2; print("patched:", label)
rep(r"const FAVVID_MANIFEST_URL = [^;]*;", "const FAVVID_MANIFEST_URL = './videos/manifest.json';", 'video manifest local', True)
rep("'https://raw.githubusercontent.com/' + FAVVID_GH_OWNER + '/' + FAVVID_GH_REPO + '/' + FAVVID_GH_BRANCH + '/' + sub.path", "'./' + sub.path", 'video files local')
rep("if (!_nat) return;\n    var base = RJAP_PWA_URL", "return; /* FULL build: audio is packed - never redirect to the website */\n    var base = RJAP_PWA_URL", 'audio redirect off')
open(p, 'w', encoding='utf-8').write(s)
PYEOF
EOS

# 2. before Gradle: create the media packs (replaces the old audio_pack)
python3 - <<'PYEOF'
p = 'build-android.sh'
s = open(p, encoding='utf-8').read()
anchor = "cd android\n./gradlew assembleRelease bundleRelease"
if anchor not in s: raise SystemExit("PATTERN NOT FOUND in build-android.sh (gradle step changed?)")
s = s.replace(anchor, "bash add-media-packs.sh\n" + anchor, 1)
open(p, 'w', encoding='utf-8').write(s)
PYEOF

rm -rf www
# DEITY_FIRST=1: only the FIRST photo of each deity is bundled (in the base module); the rest load online
AUDIO_PACK=0 DEITY_FIRST=1 bash build-android.sh "$@"

AAB=android/app/build/outputs/bundle/release/app-release.aab
if [ -f "$AAB" ]; then
  echo ""; echo "✅ FULL AAB: $(du -m "$AAB" | cut -f1) MB  ($AAB)"
fi
