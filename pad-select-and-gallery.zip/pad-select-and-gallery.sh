#!/usr/bin/env bash
# 1) Removes the "Add Your Stotram" box from the Rasik/Bhakta photo section only.
# 2) Right-side ☰ (Hit Chaurasi / Radha Sudha Nidhi): new "अपने पद चुनें / নিজের পদ বেছে নিন"
#    → tick any pads, play them one after another, with optional loop. Fixed groups unchanged.
# Run from the REPO ROOT:   bash pad-select-and-gallery.sh
set -e
[ -f app.js ] && [ -f sw.js ] && [ -f index.html ] && [ -f style-stotram.css ] || { echo "❌ Run from the repo root"; exit 1; }
python3 - <<'PYEOF'
import re, sys

app = open("app.js", encoding="utf-8").read()
if "_gpOpenSel" in app:
    sys.exit("ℹ️  Already patched — nothing to do.")

def rep(src, old, new, what, count=1):
    n = src.count(old)
    assert n == count, "anchor not found/unique for: %s (found %d)" % (what, n)
    return src.replace(old, new)

# ── 1. Hide "Add Your Stotram" only in the Rasik/Bhakta photo section (folder 'rjbj') ──
app = rep(app,
  "  if (addForm) addForm.style.display = (inVideos || inSeva || inVed) ? 'none' : '';",
  "  // Rasik / Bhakta photo gallery (folder 'rjbj'): no Add-Your-Stotram box there.\n"
  "  const inRjbj = window._stActiveFolder === 'rjbj';\n"
  "  if (addForm) addForm.style.display = (inVideos || inSeva || inVed || inRjbj) ? 'none' : '';",
  "addForm hide")

# ── 2. Playback: custom selection support (group feature untouched) ──
app = rep(app,
  "    if (_g && _g.id === _currentStotramId && idx >= _g.s && idx <= _g.e) {\n"
  "      var _nx = idx + 1;\n"
  "      if (_nx > _g.e) _nx = _g.loop ? _g.s : -1;\n",
  "    if (_g && _g.id === _currentStotramId && idx >= _g.s && idx <= _g.e && (!_g.sel || _g.sel.indexOf(idx) >= 0)) {\n"
  "      var _nx = _gpNextIdx(_g, idx);\n",
  "onended group walk")

app = rep(app,
  "idx < _hcjGroup.s || idx > _hcjGroup.e)) { _hcjGroup = null;",
  "idx < _hcjGroup.s || idx > _hcjGroup.e || (_hcjGroup.sel && _hcjGroup.sel.indexOf(idx) < 0))) { _hcjGroup = null;",
  "verse-change clear")

# a fixed group must never look 'current' while a custom selection is active
app = rep(app,
  "const same = _hcjGroup && _hcjGroup.id === _currentStotramId && _hcjGroup.s === g.s;",
  "const same = _hcjGroup && _hcjGroup.id === _currentStotramId && !_hcjGroup.sel && _hcjGroup.s === g.s;",
  "_gpStart same")
app = rep(app,
  "const isCur = act && _hcjGroup.s === g.s;",
  "const isCur = act && !_hcjGroup.sel && _hcjGroup.s === g.s;",
  "isCur")

# ── 3. Group sheet: add the 'select your own pads' button above the fixed groups ──
app = rep(app,
  "  groups.forEach(function (g) {\n    const b = document.createElement('button');\n    b.type = 'button';\n    const isCur",
  "  const _selN = (act && _hcjGroup.sel) ? _hcjGroup.sel.length : 0;\n"
  "  const selBtn = document.createElement('button');\n"
  "  selBtn.type = 'button';\n"
  "  selBtn.className = 'pp-item gp-selbtn' + (_selN ? ' pp-cur' : '');\n"
  "  selBtn.textContent = (hi ? '\\u2611 अपने पद चुनें' : '\\u2611 নিজের পদ বেছে নিন') + (_selN ? ' (' + num(_selN) + ')' : '');\n"
  "  selBtn.onclick = function () { _gpOpenSel(); };\n"
  "  list.appendChild(selBtn);\n"
  "  groups.forEach(function (g) {\n    const b = document.createElement('button');\n    b.type = 'button';\n    const isCur",
  "selBtn")

# ── 4. New code: next-pad helper, custom start, selection sheet ──
new_js = r'''// ── GROUP PLAY: pick your own pads (any pads, played in order; optional loop) ──────────────
// Fixed groups above are untouched. A custom selection is the same _hcjGroup object plus `sel` (sorted verse indexes).
function _gpNextIdx(g, idx) {
  if (g.sel) {
    var p = g.sel.indexOf(idx);
    if (p >= 0 && p + 1 < g.sel.length) return g.sel[p + 1];
    return g.loop ? g.sel[0] : -1;
  }
  var nx = idx + 1;
  if (nx > g.e) nx = g.loop ? g.s : -1;
  return nx;
}
function _gpPadList() {   // numbered pads of the current stotram → [{ idx, num, text, ok }]
  const id = _currentStotramId, cfg = _AUDIO_STOTRAMS[id], gs = _gpGroups();
  if (!gs || !cfg) return [];
  const out = [];
  for (let i = gs[0].s; i <= gs[gs.length - 1].e; i++) {
    const lb = _ppLabel(id, _verses[i], i);
    out.push({ idx: i, num: lb.num, text: lb.text, ok: !!_hcjHasAudioForIdx(cfg, i) });
  }
  return out;
}
function _gpStartSel(sel, loop) {
  sel = sel.slice().sort(function (a, b) { return a - b; });
  if (!sel.length) return;
  _hcjGroup = { id: _currentStotramId, s: sel[0], e: sel[sel.length - 1], sel: sel, loop: !!loop };
  if (_hcjMode === 'loop') { _hcjMode = 'continue'; }   // single-pad loop would trap playback on one pad
  _verseNavLocked = false;
  const old = _verseIdx;
  _verseIdx = sel[0];
  if (sel[0] !== old) { try { _renderVerse(sel[0], sel[0] > old ? 1 : -1); } catch (_e) {} }
  _hcjPlayVerse(sel[0]);
  _hcjSyncUI();
  _gpSyncBtn();
}
function _gpOpenSel() {
  const pads = _gpPadList();
  if (!pads.length) return;
  _gpClose();
  const hi = _ppIsHi();
  const lmo = document.getElementById('lmo');
  if (!lmo) return;
  const id = _currentStotramId;
  const actSel = !!(_hcjGroup && _hcjGroup.id === id && _hcjGroup.sel);
  const chosen = {};
  const memSel = (window._gpSelMem && window._gpSelMem.id === id) ? window._gpSelMem.sel : [];
  (actSel ? _hcjGroup.sel : memSel).forEach(function (i) { chosen[i] = true; });
  let loop = !!(_hcjGroup && _hcjGroup.id === id && _hcjGroup.loop);
  const num = function (n) { return _ppDigits(String(n), hi); };
  const count = function () { return pads.filter(function (p) { return chosen[p.idx]; }).length; };

  const ov = document.createElement('div');
  ov.id = 'gp-overlay';
  ov.onclick = function (e) { if (e.target === ov) _gpClose(); };
  const sheet = document.createElement('div');
  sheet.className = 'pp-sheet';
  const head = document.createElement('div');
  head.className = 'pp-head';
  const back = document.createElement('button');
  back.className = 'gp-back'; back.type = 'button'; back.textContent = '\u2190';
  back.onclick = function () { _gpOpen(); };
  const title = document.createElement('div');
  title.className = 'pp-title';
  title.textContent = hi ? 'पद चुनें' : 'পদ নির্বাচন';
  const x = document.createElement('button');
  x.className = 'pp-close'; x.type = 'button'; x.textContent = '\u2715';
  x.onclick = _gpClose;
  head.appendChild(back); head.appendChild(title); head.appendChild(x);
  sheet.appendChild(head);

  // loop ON / OFF (applies to the whole selection)
  const bar = document.createElement('div');
  bar.className = 'gp-bar';
  const mkLoop = function (want) {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'gp-loop ' + (want ? 'gp-loop-on' : 'gp-loop-off') + (loop === want ? ' on' : '');
    b.textContent = (want ? '🔁 ' : '➡️ ') + (hi ? 'चयन लूप' : 'নির্বাচিত লুপ') + (want ? ' : ON' : ' : OFF');
    b.onclick = function (e) {
      e.stopPropagation();
      loop = want;
      Array.prototype.forEach.call(bar.querySelectorAll('.gp-loop'), function (el) {
        el.classList.toggle('on', el.classList.contains('gp-loop-on') === want);
      });
      if (_hcjGroup && _hcjGroup.id === id && _hcjGroup.sel) { _hcjGroup.loop = want; _gpSyncBtn(); }   // live change while playing
    };
    return b;
  };
  bar.appendChild(mkLoop(true)); bar.appendChild(mkLoop(false));
  sheet.appendChild(bar);

  // quick-select chips
  const chips = document.createElement('div');
  chips.className = 'gp-chips';
  const rows = [];
  let playBtn;
  const refresh = function () {
    rows.forEach(function (r) {
      const on = !!chosen[r.p.idx];
      r.el.classList.toggle('on', on);
      r.ck.textContent = on ? '\u2611' : '\u2610';
      r.el.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    const n = count();
    playBtn.disabled = !n;
    playBtn.textContent = (hi ? '▶ चलाएँ' : '▶ চালান') + (n ? ' (' + num(n) + ')' : '');
  };
  const chip = function (label, fn) {
    const c = document.createElement('button');
    c.type = 'button'; c.className = 'gp-chip'; c.textContent = label;
    c.onclick = function (e) { e.stopPropagation(); fn(); refresh(); };
    chips.appendChild(c);
  };
  chip(hi ? 'सभी' : 'সব', function () { pads.forEach(function (p) { if (p.ok) chosen[p.idx] = true; }); });
  chip(hi ? 'साफ़' : 'মুছুন', function () { Object.keys(chosen).forEach(function (k) { delete chosen[k]; }); });
  const tabs = (typeof PADPICK_TABS !== 'undefined') ? PADPICK_TABS[id] : null;
  if (tabs) {
    const byTab = function (key) {
      return function () {
        Object.keys(chosen).forEach(function (k) { delete chosen[k]; });
        pads.forEach(function (p) { if (p.ok && tabs[key].indexOf(_ppNumInt(p.num)) !== -1) chosen[p.idx] = true; });
      };
    };
    if (tabs.mangala) chip(hi ? 'मंगला के पद' : 'মঙ্গলার পদ', byTab('mangala'));
    if (tabs.ras) chip(hi ? 'रास के पद' : 'রাসের পদ', byTab('ras'));
  }
  sheet.appendChild(chips);

  // pad checklist
  const list = document.createElement('div');
  list.className = 'pp-list';
  pads.forEach(function (p) {
    const el = document.createElement('button');
    el.type = 'button';
    el.className = 'pp-item gp-sel-row';
    el.disabled = !p.ok;
    const ck = document.createElement('span'); ck.className = 'gp-ck';
    const nm = document.createElement('span'); nm.className = 'gp-num'; nm.textContent = p.num ? p.num + '.' : '';
    const tx = document.createElement('span'); tx.className = 'gp-tx'; tx.textContent = p.text;
    el.appendChild(ck); el.appendChild(nm); el.appendChild(tx);
    el.onclick = function () { if (chosen[p.idx]) delete chosen[p.idx]; else chosen[p.idx] = true; refresh(); };
    list.appendChild(el);
    rows.push({ p: p, el: el, ck: ck });
  });
  sheet.appendChild(list);

  // play button (selection plays in pad order, one after another)
  const foot = document.createElement('div');
  foot.className = 'gp-foot';
  playBtn = document.createElement('button');
  playBtn.type = 'button'; playBtn.className = 'gp-play';
  playBtn.onclick = function () {
    const sel = pads.filter(function (p) { return chosen[p.idx]; }).map(function (p) { return p.idx; });
    if (!sel.length) return;
    window._gpSelMem = { id: id, sel: sel };
    _gpClose();
    _gpStartSel(sel, loop);
  };
  foot.appendChild(playBtn);
  sheet.appendChild(foot);
  refresh();
  ov.appendChild(sheet);
  lmo.appendChild(ov);
  // bring the first chosen pad into view
  try { const f = list.querySelector('.gp-sel-row.on'); if (f) f.scrollIntoView({ block: 'center' }); } catch (_e) {}
}
'''
app = rep(app,
  "// (Re)place the right-side ☰: bottom-right, just above the audio player (mirrors the left pad picker).",
  new_js + "// (Re)place the right-side ☰: bottom-right, just above the audio player (mirrors the left pad picker).",
  "insert new functions")
open("app.js", "w", encoding="utf-8").write(app)

# ── 5. CSS ──
css = open("style-stotram.css", encoding="utf-8").read()
css += r'''

/* ═══ GROUP PLAY — pick your own pads (checklist sheet) ═══ */
#gp-overlay .gp-selbtn { border-style: dashed; }
#gp-overlay .gp-back {
  position: absolute; top: 12px; left: 12px; width: 34px; height: 34px; border-radius: 50%;
  background: rgba(255,215,0,0.14); color: #ffd700; border: 1px solid rgba(255,215,0,0.4);
  font-size: 18px; line-height: 1; cursor: pointer;
}
#gp-overlay .gp-chips { flex: 0 0 auto; display: flex; flex-wrap: wrap; gap: 8px; padding: 0 14px 10px; }
#gp-overlay .gp-chip {
  flex: 1 1 auto; min-height: 38px; padding: 6px 14px; border-radius: 20px;
  border: 1px solid rgba(255,215,0,0.45); background: rgba(255,215,0,0.10); color: #ffd700;
  font-family: inherit; font-size: 13px; font-weight: 700; cursor: pointer;
}
#gp-overlay .gp-chip:active { background: rgba(255,215,0,0.28); }
#gp-overlay .gp-sel-row { display: flex; align-items: center; gap: 10px; text-align: left; padding: 8px 14px; }
#gp-overlay .gp-sel-row.on { background: rgba(255,215,0,0.22); border-color: #ffd700; box-shadow: 0 0 0 1px #ffd700; }
#gp-overlay .gp-sel-row[disabled] { opacity: 0.35; cursor: default; }
#gp-overlay .gp-ck { flex: 0 0 auto; font-size: 20px; line-height: 1; }
#gp-overlay .gp-num { flex: 0 0 auto; min-width: 2.6em; color: #ffd700; font-weight: 800; }
#gp-overlay .gp-tx { flex: 1 1 auto; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-weight: 600; }
#gp-overlay .gp-foot { flex: 0 0 auto; padding: 10px 14px calc(12px + env(safe-area-inset-bottom)); border-top: 1px solid rgba(255,215,0,0.25); }
#gp-overlay .gp-play {
  width: 100%; min-height: 48px; border: none; border-radius: 26px;
  background: linear-gradient(180deg, #ffd700, #ff9800); color: #1a1100;
  font-family: inherit; font-size: 16px; font-weight: 800; cursor: pointer;
}
#gp-overlay .gp-play[disabled] { opacity: 0.4; cursor: default; }
'''
open("style-stotram.css", "w", encoding="utf-8").write(css)

# ── 6. cache versions ──
sw = open("sw.js", encoding="utf-8").read()
m = re.search(r"const CACHE = 'radha-jap-v(\d+)'", sw)
if m:
    sw = sw.replace(m.group(0), "const CACHE = 'radha-jap-v%d'" % (int(m.group(1)) + 1), 1)
open("sw.js", "w", encoding="utf-8").write(sw)
ix = open("index.html", encoding="utf-8").read()
ix = re.sub(r"app\.js\?v=(\d+)", lambda m: "app.js?v=%d" % (int(m.group(1)) + 1), ix, count=1)
ix = re.sub(r"style-stotram\.css\?v=(\d+)", lambda m: "style-stotram.css?v=%d" % (int(m.group(1)) + 1), ix, count=1)
open("index.html", "w", encoding="utf-8").write(ix)
print("▶ app.js, style-stotram.css, sw.js, index.html patched")
PYEOF
command -v node >/dev/null && node --check app.js && node --check sw.js && echo "▶ JS syntax OK"
echo "✅ Done. Review with: git diff --stat"
