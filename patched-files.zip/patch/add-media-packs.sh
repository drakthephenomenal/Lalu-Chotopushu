#!/bin/bash
# ============================================================================
# add-media-packs.sh
#
# Puts ALL audio/, videos/ and stotram-live/ into Play Asset Delivery
# "install-time" asset packs (media_pack_1, media_pack_2, ...), each kept under
# ~900 MB, so the AAB is accepted by Google Play (the base module stays small).
# Install-time packs are merged into the app's asset tree, so './audio/x.mp3'
# works exactly like in the full offline APK.
#
# Run from the repo root AFTER `npx cap sync` (android/ must exist).
# ============================================================================
set -e
MAX_MB="${PACK_MAX_MB:-900}"
FOLDERS="audio videos stotram-live"      # deities/: only first photos, bundled by add-deity-first-photos.py

[ -d android ] || { echo "::error::android/ not found - run after the project is generated."; exit 1; }
MAXB=$(( MAX_MB * 1024 * 1024 ))
rm -rf android/media_pack_*

PACKS=0; CUR=0; TOTAL=0; DEST=""
newpack() {
  PACKS=$((PACKS + 1)); CUR=0
  DEST="android/media_pack_${PACKS}/src/main/assets/public"
  mkdir -p "$DEST"
}

for d in $FOLDERS; do
  [ -d "$d" ] || { echo "  (skipping missing folder: $d/)"; continue; }
  while IFS= read -r -d '' f; do
    sz=$(stat -c%s "$f")
    if [ "$sz" -gt "$MAXB" ]; then
      echo "::error::$f is $((sz/1024/1024)) MB - bigger than one pack ($MAX_MB MB)."; exit 1
    fi
    if [ "$PACKS" -eq 0 ] || [ $((CUR + sz)) -gt "$MAXB" ]; then newpack; fi
    mkdir -p "$DEST/$(dirname "$f")"
    ln "$f" "$DEST/$f" 2>/dev/null || cp "$f" "$DEST/$f"     # hard link when possible: no extra disk
    CUR=$((CUR + sz)); TOTAL=$((TOTAL + sz))
  done < <(find "$d" -type f -print0 | sort -z)
done

[ "$PACKS" -gt 0 ] || { echo "::error::No files found in: $FOLDERS"; exit 1; }
echo "  media packs: $PACKS pack(s), $((TOTAL/1024/1024)) MB total"

LIST=""
for i in $(seq 1 "$PACKS"); do
  cat > "android/media_pack_${i}/build.gradle" <<GRADLE
apply plugin: 'com.android.asset-pack'

assetPack {
    packName = "media_pack_${i}"
    dynamicDelivery {
        deliveryType = "install-time"
    }
}
GRADLE
  grep -q "':media_pack_${i}'" android/settings.gradle || printf "\ninclude ':media_pack_%s'\n" "$i" >> android/settings.gradle
  LIST="${LIST}\":media_pack_${i}\","
done
LIST="[${LIST%,}]"

PACK_LIST="$LIST" python3 - <<'PYEOF'
import os, re
p = "android/app/build.gradle"
t = open(p, encoding="utf-8").read()
if "assetPacks" in t:
    raise SystemExit("::error::app/build.gradle already has assetPacks (audio pack still enabled?)")
t2, n = re.subn(r"(^android\s*\{\s*\n)", r"\1    assetPacks = " + os.environ["PACK_LIST"] + "\n", t, count=1, flags=re.M)
if n != 1: raise SystemExit("::error::could not find the android { block in android/app/build.gradle")
open(p, "w", encoding="utf-8").write(t2)
print("  app/build.gradle: assetPacks =", os.environ["PACK_LIST"])
PYEOF
