#!/usr/bin/env bash
# Adds "Bhori Sakhi ji" to the Rashik Sant gallery (Radhavallabh group)
# and shows his photo as the icon beside "Prem Ki Peer" (id: pkp) in S&V.
# Put this script, p086.jpg and bhori-icon-96.jpg in ONE folder, then run it
# from the REPO ROOT:   bash /path/to/add-bhori-sakhi.sh
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
[ -f app.js ] && [ -f sw.js ] && [ -f index.html ] && [ -d rashikan ] || { echo "❌ Run this from the repo root (app.js, sw.js, rashikan/ must be here)"; exit 1; }
[ -f "$HERE/p086.jpg" ] && [ -f "$HERE/bhori-icon-96.jpg" ] || { echo "❌ p086.jpg / bhori-icon-96.jpg missing next to the script"; exit 1; }
[ -e rashikan/p086.jpg ] && { echo "ℹ️  rashikan/p086.jpg already exists — nothing to do."; exit 0; }

cp "$HERE/p086.jpg" rashikan/p086.jpg
echo "▶ Photo copied → rashikan/p086.jpg"

HERE="$HERE" python3 - <<'PY'
import base64, json, os, re, sys
here = os.environ["HERE"]
app = open("app.js", encoding="utf-8").read()
if "RV_POET_IMG.bhs" in app or "p086.jpg" in app:
    sys.exit("already patched")

# ── 1. S&V icon: Prem Ki Peer (pkp) → Bhori Sakhi ji ────────────────
icon = base64.b64encode(open(os.path.join(here, "bhori-icon-96.jpg"), "rb").read()).decode()
anchor = "// Reuse the folder-tile icons already embedded below for Jayadeva and Najrul."
assert anchor in app, "icon anchor not found"
app = app.replace(anchor,
    '// Bhori Sakhi ji — author of Prem Ki Peer (rashikan p086).\n'
    'RV_POET_IMG.bhs = "data:image/jpeg;base64,' + icon + '";\n'
    'RV_POET_ICON.pkp = "bhs";\n' + anchor, 1)

# ── 2. Rashik Sant gallery entry (group: rasik) ─────────────────────
hi_detail = (
"श्री भोरी सखी जी (श्री भोलानाथ जी) राधावल्लभ परम्परा के रसिक सन्त हैं और 'प्रेम की पीर' के रचयिता। आप परम पूज्य गोस्वामी श्रीहित गोवर्धन लाल जी महाराज के शिष्य हैं। इनका विस्तृत जीवन-परिचय अभी संकलित नहीं हुआ है।\n\n"
"सद्गुरुदेव — गोस्वामी श्रीहित गोवर्धन लाल जी महाराज\n\n"
"जन्म और परिवार: विक्रम संवत 1918, कार्तिक कृष्ण द्वितीया को श्रीधाम वृन्दावन में। पिता गोस्वामी श्री जोगल लाल जी, माता श्रीमती बसंत कुँवारी जी। बाल्यकाल से ही अद्भुत चरित्र और अलौकिक स्वभाव के कारण लोग इन्हें अवतारी महापुरुष मानते थे। विवाह लगभग संवत 1940–41 में हुआ; पुत्र गोस्वामी राधा लाल जी और पुत्री ललिता।\n\n"
"सेवा: बचपन से श्री वल्लभ लाल जी की रूप-माधुरी और सेवा में गहरा अनुराग; श्रीराधावल्लभ मन्दिर के राजवंशीय सेवा-अधिकारी रहे। श्यामा-श्याम का श्रृंगार करते समय उनकी छवि में ऐसे खो जाते कि समय का भान नहीं रहता — इसी से उक्ति प्रसिद्ध हुई \"राधा वल्लभ दर्शन दुर्लभ\"। मन्दिर के नित्य समाज-गान के प्रमुख मुखिया भी रहे।\n\n"
"शिष्य और प्रचार: रसिकवर श्री राधिका शरण जी, श्री प्रीतम दास जी और श्री भोलानाथ जी (भोरी सखी जी) इनके प्रमुख शिष्यों में हैं। हित धर्म के प्रचार हेतु मध्य प्रदेश के सिवनी गए और श्री राधा वल्लभ लाल जी के नवीन मन्दिर की स्थापना की (गौर वर्ण युगल स्वरूप)।\n\n"
"रचनाएँ: बसंत, होली, डोल, चन्दन, जल-विहार, पावस, झूलन, दीपावली, खिचड़ी आदि लीलाओं के रसमय पद।\n\n"
"निकुंज गमन: संवत 1975 के आसपास माना जाता है। मुख्य उपदेश: संसार के प्रपंच से दूर रहकर निरन्तर \"श्री राधा वल्लभ श्री हरिवंश\" नाम का जप और गुरु-चरणों में पूर्ण शरणागति।")
bn_detail = (
"শ্রী ভোরী সখী জী (শ্রী ভোলানাথ জী) রাধাবল্লভ পরম্পরার রসিক সন্ত এবং 'প্রেম কী পীর'-এর রচয়িতা। তিনি পরম পূজ্য গোস্বামী শ্রীহিত গোবর্ধন লাল জী মহারাজের শিষ্য। তাঁর বিস্তারিত জীবনপরিচয় এখনও সংকলিত হয়নি।\n\n"
"সদ্গুরুদেব — গোস্বামী শ্রীহিত গোবর্ধন লাল জী মহারাজ\n\n"
"জন্ম ও পরিবার: বিক্রম সংবত ১৯১৮, কার্তিক কৃষ্ণ দ্বিতীয়ায় শ্রীধাম বৃন্দাবনে। পিতা গোস্বামী শ্রী জোগল লাল জী, মাতা শ্রীমতী বসন্ত কুঁয়ারী জী। শৈশব থেকেই অদ্ভুত চরিত্র ও অলৌকিক স্বভাবের জন্য লোকে তাঁকে অবতারী মহাপুরুষ মনে করত। বিবাহ আনুমানিক সংবত ১৯৪০–৪১-এ; পুত্র গোস্বামী রাধা লাল জী ও কন্যা ললিতা।\n\n"
"সেবা: শৈশব থেকেই শ্রী বল্লভ লাল জীর রূপ-মাধুরী ও সেবায় গভীর অনুরাগ; শ্রীরাধাবল্লভ মন্দিরের রাজবংশীয় সেবা-অধিকারী ছিলেন। শ্যামা-শ্যামের শৃঙ্গার করার সময় তাঁদের ছবিতে এমন ডুবে যেতেন যে সময়ের হুঁশ থাকত না — তাই প্রসিদ্ধ হয়েছে \"রাধা বল্লভ দর্শন দুর্লভ\"। মন্দিরের নিত্য সমাজ-গানের প্রধান মুখিয়াও ছিলেন।\n\n"
"শিষ্য ও প্রচার: রসিকবর শ্রী রাধিকা শরণ জী, শ্রী প্রীতম দাস জী ও শ্রী ভোলানাথ জী (ভোরী সখী জী) তাঁর প্রধান শিষ্যদের অন্যতম। হিত ধর্ম প্রচারের জন্য মধ্যপ্রদেশের সিওনি গিয়ে শ্রী রাধা বল্লভ লাল জীর নতুন মন্দির প্রতিষ্ঠা করেন (গৌর বর্ণ যুগল স্বরূপ)।\n\n"
"রচনা: বসন্ত, হোলি, দোল, চন্দন, জলবিহার, পাবস, ঝুলন, দীপাবলি, খিচুড়ি প্রভৃতি লীলার রসময় পদ।\n\n"
"নিকুঞ্জগমন: সংবত ১৯৭৫-এর কাছাকাছি বলে ধরা হয়। মূল উপদেশ: সংসারের প্রপঞ্চ থেকে দূরে থেকে নিরন্তর \"শ্রী রাধা বল্লভ শ্রী হরিবংশ\" নাম জপ এবং গুরুচরণে পূর্ণ শরণাগতি।")
item = {
 "file": "./rashikan/p086.jpg",
 "hi": "रसिक सन्त श्री भोरी सखी जी (श्री भोलानाथ जी)",
 "bn": "রসিক সন্ত শ্রী ভোরী সখী জী (শ্রী ভোলানাথ জী)",
 "g": "rasik",
 "nh": "राधावल्लभ परम्परा के रसिक सन्त; सद्गुरुदेव गोस्वामी श्रीहित गोवर्धन लाल जी महाराज के शिष्य। 'प्रेम की पीर' के रचयिता।",
 "nb": "রাধাবল্লভ পরম্পরার রসিক সন্ত; সদ্গুরুদেব গোস্বামী শ্রীহিত গোবর্ধন লাল জী মহারাজের শিষ্য। 'প্রেম কী পীর'-এর রচয়িতা।",
 "dh": hi_detail, "db": bn_detail}
js = "  { " + ", ".join(
    (k + ": " + json.dumps(v, ensure_ascii=False)) for k, v in item.items()) + " },"
lines = app.split("\n")
idx = [i for i, l in enumerate(lines) if "./rashikan/p069.jpg" in l and l.rstrip().endswith("},")]
assert len(idx) == 1, "Prem Das (p069) anchor not found"
lines.insert(idx[0] + 1, js)       # right after Prem Das ji, inside the Rasik group
app = "\n".join(lines)
open("app.js", "w", encoding="utf-8").write(app)

# ── 3. Service worker: precache the photo + bump cache version ──────
sw = open("sw.js", encoding="utf-8").read()
assert "'./rashikan/p085.jpg'," in sw, "sw.js anchor not found"
sw = sw.replace("  './rashikan/p085.jpg',", "  './rashikan/p085.jpg',\n  './rashikan/p086.jpg',", 1)
m = re.search(r"const CACHE = 'radha-jap-v(\d+)'", sw)
if m:
    sw = sw.replace(m.group(0), "const CACHE = 'radha-jap-v%d'" % (int(m.group(1)) + 1), 1)
open("sw.js", "w", encoding="utf-8").write(sw)

# ── 4. index.html: new app.js version so the update is picked up ────
ix = open("index.html", encoding="utf-8").read()
ix = re.sub(r"app\.js\?v=(\d+)", lambda m: "app.js?v=%d" % (int(m.group(1)) + 1), ix, count=1)
open("index.html", "w", encoding="utf-8").write(ix)
print("▶ app.js, sw.js, index.html patched")
PY
command -v node >/dev/null && node --check app.js && node --check sw.js && echo "▶ JS syntax OK"
echo "✅ Done. Review with: git diff --stat   then commit & build."
